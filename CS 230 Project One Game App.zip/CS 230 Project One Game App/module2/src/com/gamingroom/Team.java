package com.gamingroom;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	//A list of active teams
	private List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	
	/**
	 * uses iterator pattern to find existing player with
	 * same name or adds unique named player to list
	 * 
	 * @param name
	 * @return Player instance
	 */
	public Player addPlayer(String name) {
		
		//a local teams instance
		Player player = null;
		
		//instance iterator
		Iterator<Player> playersIterator = players.iterator();
		
		//Iterate over players list
		while (playersIterator.hasNext()) {
			
			//set local Player var to next item in list
			Player playerInstance = playersIterator.next();
			
			//Does player name exist
			if (playerInstance.getName().equalsIgnoreCase(name)) {
				//if player name already exists return player instance
				player = playerInstance;
			} else {
				//else add player to players list
				players.add(player);
			}
		}
		
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
